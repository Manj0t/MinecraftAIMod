package me.sand.minecraftaimod;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_10192;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1835;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_4174;
import net.minecraft.class_5134;
import net.minecraft.class_5354;
import net.minecraft.class_7923;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.class_9424;
import net.minecraft.item.*;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.List;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;


public class Minecraftaimod implements ModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("collect-state-info");
    private boolean collecting = false;

    private class_3222 agent = null;
    private String agentName = null;

    private class_1661 agentInventory = null;
    class_1937 world = null;



    @Override
    public void onInitialize() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    method_9247("start_training")
                            .then(method_9244("agentName", StringArgumentType.string())
                                    .executes(ctx -> {
                                        MinecraftServer server = ctx.getSource().method_9211();
                                        agentName = StringArgumentType.getString(ctx, "agentName").toLowerCase();

                                        server.method_3734().method_44252(server.method_3739(), "/player " + agentName + " spawn");

//                                        collecting = true;
                                        ctx.getSource().method_9226(() -> class_2561.method_43470("Started training!"), false);

                                        try {
//                                            ProcessBuilder pb = new ProcessBuilder("python3", "python_socket.py");
                                            System.out.println("INFO: Made process");
//                                            pb.start();
                                            System.out.println("INFO: Started Process");
                                            Thread.sleep(1000);
                                            System.out.println("INFO: FINISHED SLEEPING");

                                            Socket socket = new Socket("localhost", 5000);
                                            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                                            System.out.println("INFO: Got other variables");
                                            out.println("Hello Minecraft");
                                            System.out.println("Python replied " + in.readLine());

                                            out.println("exit");
                                            System.out.println("Python replied: " + in.readLine());

                                            socket.close();
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            System.out.println("ERROR: FAILED ");
                                        }

                                        return 1;
            })));


            dispatcher.register(method_9247("stop_training").executes(ctx -> {
                MinecraftServer server = ctx.getSource().method_9211();
                server.method_3734().method_44252(server.method_3739(), "/player " + agentName + " kill");

                agent = null;
                agentName = null;

                collecting = false;
                ctx.getSource().method_9226(() -> class_2561.method_43470("Stopped training!"), false);
                return 1;
            }));
        });


        /*
         ************************************************
         **   Main State Information Collection Loop   **
         ************************************************
         */
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!collecting) return; // only run if training started
            if (agent == null && agentName != null) {
                for (class_3222 player : server.method_3760().method_14571()) {
                    if (agentName.equals(player.method_5477().getString().toLowerCase())) {
                        agent = player;
                        world = agent.method_51469();
                        System.out.println("found");
                        break;
                    }
                }
                if (agent == null) return;
            }
            // Agent Position Information
            double[] agentInfo = getAgentInfo();
            System.out.println(Arrays.toString(agentInfo));
            // Get agent inventory
            // Pass through transformer to encode values as a flattened vector
            double[][] inventoryArray = getInventory();
            System.out.println(Arrays.deepToString(inventoryArray));

            // Get nearby entities
            double[][] nearbyEntities = getNearbyEntities();
            System.out.println(Arrays.deepToString(nearbyEntities));

            // Get nearby Block information
            double[][] nearbyBlocks = getNearbyBlocks();
            System.out.println(Arrays.deepToString(nearbyBlocks));


//            StateOuterClass.Matrix.Builder inventoryMatrix =


        });
    }

    private double[] getAgentInfo(){
        double health = agent.method_6032();
        double hunger = agent.method_7344().method_7586();
        double saturation = agent.method_7344().method_7589();

        double[] agentPos = getPos();

        class_243 vel = agent.method_18798();
        double vx = vel.field_1352;
        double vy = vel.field_1351;
        double vz = vel.field_1350;

        class_2680 blockBelow = world.method_8320(agent.method_24515().method_10074());
        double blockBelowId = class_2248.field_10651.method_10206(blockBelow);

        double colliding = agent.field_5976 || agent.field_5992 ? 1 : 0;
        double isSneak = agent.method_5715() ? 1 : 0;

        double isOnFire = agent.method_5809() ? 1 : 0;
        double inWater = agent.method_5799() ? 1 : 0;
        double inLava = agent.method_5771() ? 1 : 0;
        double onGround = agent.method_24828() ? 1 : 0;
        double isFalling  = vy < -0.6 ? 1 : 0;
        double wasHurt = agent.field_6235 > 0 ? 1 : 0;

        double mainHandCount = agent.method_6047().method_7947();
        double mainHandSlot = agent.method_31548().method_67532();

        double time = (double) world.method_8510();
        double lightLevel = world.method_22339(agent.method_24515());

        double[] agentInfo = new double[]{
                health,
                hunger,
                saturation,
                agentPos[0],
                agentPos[1],
                agentPos[2],
                vx,
                vy,
                vz,
                blockBelowId,
                colliding,
                isSneak,
                isOnFire,
                inWater,
                inLava,
                onGround,
                isFalling,
                wasHurt,
                mainHandCount,
                mainHandSlot,
                time,
                lightLevel,
        };

        return agentInfo;
    }
    private double[] getPos() {
        return new double[]{ agent.method_23317(), agent.method_23318(), agent.method_23321(), agent.method_36454(), agent.method_36455() };
    }

    /**
     * Used to collect the possible utility values of an item
     * @param item The {@link class_1792} to find the possible utilities of
     * @param itemType The {@link int[]} representing the type of item, if provided [isArmor, isFodd, isTool, isWeapon]
     * @return array of 2 values representing 2 utility options.
     *         isArmor: [protection, toughness]
     *         isFood: [nutrition, saturation]
     *         isTool: [dmg per block, default mining speed]
     *         isWeapon: [dmg, attack speed]
     */
    private double[] getUtility(class_1792 item, int[] itemType) {
        double[] utility = {0, 0};
        // isArmor
        if(itemType[0] == 1) {
            // [protection, toughness]
            class_9285 modifiers = item.method_57347().method_58694(class_9334.field_49636);

            if (modifiers == null) return utility;

            for (var modifier : modifiers.comp_2393()) {
                if (modifier.comp_2395().equals(class_5134.field_23724)) {
                    utility[0] += modifier.comp_2396().comp_2449();
                }
                if (modifier.comp_2395().equals(class_5134.field_23725)) {
                    utility[1] += modifier.comp_2396().comp_2449();
                }
            }
        }
        // isFood
        else if(itemType[1] == 1) {
            // [nutrition (hunger fill), saturation (how long)]
            class_4174 food = item.method_57347().method_58694(class_9334.field_50075);

            if (food == null) return utility;

            utility[0] = food.comp_2491();
            utility[1] = food.comp_2492();
        }
        // isTool
        else if(itemType[2] == 1){
            // [damage per block, default mining speed]
            class_9424 tool = item.method_57347().method_58694(class_9334.field_50077);

            if(tool == null) return utility;

            utility[0] = tool.comp_2500();
            utility[1] = tool.comp_2499();
        }
        //isWeapon
        else if(itemType[3] == 1){
            // Handle Ranged weapons
            // [based dmg, draw time]
            if (item instanceof class_1753) {
                utility[0] = 6.0;
                utility[1] = 0.80;
                return utility;
            }
            if  (item instanceof class_1764) {
                utility[0] = 6.0;
                utility[1] = 0.50;
                return utility;
            }

            // [damage, attack speed]
            class_9285 modifiers = item.method_57347().method_58694(class_9334.field_49636);

            if (modifiers == null) return utility;

            for (var modifier : modifiers.comp_2393()) {
                if (modifier.comp_2395().equals(class_5134.field_23721)) {
                    utility[0] += modifier.comp_2396().comp_2449();
                }
                if (modifier.comp_2395().equals(class_5134.field_23723)) {
                    utility[1] += modifier.comp_2396().comp_2449();
                }
            }

        }
        return utility;
    }

    /**
     * Gets the agent inventory.
     * 0–8   : Hotbar
     * 9–35  : Main inventory
     * 36–39  : Armor (boots → leggings → chestplate → helmet)
     * 40     : Off-hand
     * 41–44  : Crafting grid output + 2x2 crafting input (ignored)
     *
     * @return double[][] where each row =
     *         [item_id, count, durability, isArmor, isFood, isTool, isWeapon, utility1, utility2]
     *         Check getUtility function for posible utility values
     */
    private double[][] getInventory(){
        agentInventory = agent.method_31548();
        double[][] inventoryArray =  new double[41][9];

        for(int i = 0; i <= 40; i++) {
            class_1799 stack = agentInventory.method_5438(i);
            class_1792 item = stack.method_7909();

            int item_id = class_1792.method_7880(item);
            int count = stack.method_7947();
            int durability = stack.method_7936() - stack.method_7919();

            // ------ Get Boolean Values For one-hot encoding of item type ------ //
            class_10192 equip = item.method_57347().method_58694(class_9334.field_54196);
            int isArmor = 0;
            if(equip != null) {
                class_1304 slot = equip.comp_3174();
                isArmor = (slot.method_5925() == class_1304.class_1305.field_6178) ? 1 : 0;
            }

            boolean toolBool = item.method_57347().method_57832(class_9334.field_50077);
            boolean foodBool = item.method_57347().method_57832(class_9334.field_50075);
            boolean weaponBool = item == class_1802.field_8091 || item == class_1802.field_8528 || item == class_1802.field_8371 || item == class_1802.field_8845 || item == class_1802.field_8802 || item == class_1802.field_22022;
            boolean rangedWeaponBool = item instanceof class_1753 || item instanceof class_1764 || item instanceof class_1835;

            int isTool = toolBool ? 1 : 0;
            int isFood = foodBool ? 1 : 0;
            int isWeapon = 0;

            if(weaponBool || rangedWeaponBool) {
                // Sword is both tool and weapon, but we want it to only be classified as weapon
                isWeapon = 1;
                isTool = 0;
            }

            int[] itemType = {isArmor, isFood, isTool, isWeapon};

            // Get utility value based on what the item is. We will get 2 per option
            double[] utility_value = getUtility(item, itemType);

            inventoryArray[i][0] = item_id;
            inventoryArray[i][1] = count;
            inventoryArray[i][2] = durability;
            inventoryArray[i][3] = isArmor;
            inventoryArray[i][4] = isFood;
            inventoryArray[i][5] = isTool;
            inventoryArray[i][6] = isWeapon;
            inventoryArray[i][7] = utility_value[0];
            inventoryArray[i][8] = utility_value[1];;
        }

        return inventoryArray;
    }

    /**
     * Gets Entities within a given radius of the agent
     * @return double[][] where each row =
     *         [entity id, x, y, z, isMonster, isAngerable, isPassive, isUnknown]
     */
    private double[][] getNearbyEntities(){
        double agentSearchRadius = 10.0;
        double[][] foundEntities = new double[10][8];

        class_238 box = agent.method_5829().method_1014(agentSearchRadius);
        List<class_1297> nearbyEntities = agent.method_51469().method_8335(agent, box);

        for (int i = 0; i < nearbyEntities.size(); i++) {
            class_1297 entity = nearbyEntities.get(i);
            if (entity instanceof class_1657 || !(entity instanceof class_1309)) continue;

            int isMonster = entity instanceof class_1569 ? 1 : 0;
            int isAngerable = entity instanceof class_5354 ? 1 : 0;
            int isPassive = entity instanceof class_1296 ? 1 : 0;
            int isUnknown = (isMonster != 1 && isAngerable != 1 && isPassive != 1) ? 1 : 0;

            foundEntities[i][0] = class_7923.field_41177.method_10206(entity.method_5864());
            foundEntities[i][1] = entity.method_23317() - agent.method_23317();
            foundEntities[i][2] = entity.method_23318() - agent.method_23318();
            foundEntities[i][3] = entity.method_23321() - agent.method_23321();
            foundEntities[i][4] = isMonster;
            foundEntities[i][5] = isAngerable;
            foundEntities[i][6] = isPassive;
            foundEntities[i][7] = isUnknown;
        }

        // Runs and sets default value for no entities if less than 10 entities found
        for(int i = nearbyEntities.size(); i < 10; i++) {
            foundEntities[i][0] = 0;
            foundEntities[i][1] = 0;
            foundEntities[i][2] = 0;
            foundEntities[i][3] = 0;
            foundEntities[i][4] = 0;
            foundEntities[i][5] = 0;
            foundEntities[i][6] = 0;
            foundEntities[i][7] = 0;
        }

        return foundEntities;
    }

    /**
     * Gets nearby blocks of the agent given a radius
     * @return double[][] where each row =
     *         [Block id, x, y, z]
     */
    private double[][] getNearbyBlocks() {
        int radius = 5;
        int verticalRadius = 3; // Vertical space not as significant

        int rows = ( (radius * 2) + 1) * ( (verticalRadius * 2) + 1) * ( (radius * 2) + 1 );
        double[][] foundBlocks = new double[rows][4];

        int agentBlockX = agent.method_31477();
        int agentBlockY = agent.method_31478();
        int agentBlockZ = agent.method_31479();

        int idx = 0;
        for(int x = agent.method_31477() - radius; x <= agentBlockX + radius; x++) {
            for (int y = agent.method_31478() - verticalRadius; y <= agentBlockY + verticalRadius; y++) {
                for(int z = agent.method_31479() - radius; z <= agentBlockZ + radius; z++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = agent.method_51469().method_8320(pos);

                    int relativeBlockX = x -  agentBlockX;
                    int relativeBlockY = y - agentBlockY;;
                    int relativeBlockZ = z - agentBlockZ;

                    foundBlocks[idx][0] = class_2248.field_10651.method_10206(state);
                    foundBlocks[idx][1] = relativeBlockX;
                    foundBlocks[idx][2] = relativeBlockY;
                    foundBlocks[idx][3] = relativeBlockZ;

                    idx++;
                }
            }
        }
        return foundBlocks;
    }
}