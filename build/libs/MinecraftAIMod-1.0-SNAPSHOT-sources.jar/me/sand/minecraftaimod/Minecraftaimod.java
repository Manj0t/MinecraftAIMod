package me.sand.minecraftaimod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import me.sand.minecraftaimod.protobuf.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_10192;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1675;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1835;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4174;
import net.minecraft.class_5134;
import net.minecraft.class_5354;
import net.minecraft.class_7923;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.class_9424;
import net.minecraft.item.*;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.*;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;


public class Minecraftaimod implements ModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("collect-state-info");
    private volatile boolean collecting = false;

    private class_3222 agent = null;
    private String agentName = null;
//    private PlayerInventory agentInventory = null;
    class_1937 world = null;


    Socket socket = null;
    private ServerSocket serverSocket;
    DataInputStream input = null;
    DataOutputStream output = null;

    private volatile boolean sendState = false;
    private volatile boolean sendReward = false;
    private volatile boolean recieveAction = false;
    private volatile boolean waitForNextRollout = false;
    private volatile boolean resetPlayer = false;

    private final Map<Integer, Runnable> movementActions = new HashMap<>();
    private final Map<Integer, Runnable> panCam = new HashMap<>();
    private final Map<Tuple3, Float> checkpoints = new HashMap<>();
//    private HashSet<Point> visitedRegion = new HashSet<>();

    private int currentHand = 0;
    private double speed = 0.24;
    double maxSpeed = 0.25;

    class_243 lastPos = null;
    Double lastY = null;
    float penalty = 0;
    boolean wasOnGround = false;
    double agentPrevhealth = 0;

    class_2338 nearestWood = null;

    record Tuple3(int x, int y, int z) {}

    Set<Tuple3> visitedRegion = new HashSet<>();
    Set<Tuple3> visitedWood = new HashSet<>();

    int loop = 0;
    boolean isLavaArea = false;

    boolean spawnPlayer = false;

    Deque<class_243> pastPositions = new ArrayDeque<>();
    final int WINDOW = 10; // 10 ticks = 0.5 sec
    int lastMovement = 0;

    int prevMoveAction = -1;
    boolean isStuck = false;

    int forwardConsistency = 0;

    int stuckCounter = 0;
    int agentPort = -1;

    boolean DEBUGCHECKPOINT = false;
    boolean DEBUGSTUCK = false;

    private final int REGION = 1;   // IMPORTANT: use 2 or 3 in a narrow maze

    boolean doLookWood = true;
    public static class_2168 cmdSrc = null;

    int prev_num_logs = 0;
    @Override
    public void onInitialize() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    method_9247("start_training")
                            .then(method_9244("agentName", StringArgumentType.string())
                                    .then(method_9244("agentPort", IntegerArgumentType.integer())
                                        .executes(ctx -> {
                                            cmdSrc = ctx.getSource();
                                            MinecraftServer server = ctx.getSource().method_9211();
                                            agentName = StringArgumentType.getString(ctx, "agentName").toLowerCase();
                                            agentPort = IntegerArgumentType.getInteger(ctx, "agentPort");

                                            server.method_3734().method_44252(server.method_3739(), "/player " + agentName + " spawn");


                                            collecting = true;

                                            server.method_3734().method_44252(server.method_3739(), "/tick rate 35");
                                            ctx.getSource().method_9226(() -> class_2561.method_43470("Started training!"), false);
                                            try {
                                                if (socket != null) {
                                                    socket.close();
                                                    socket = null;
                                                }
                                            } catch (IOException e) {
                                                //nothing
                                            }

                                            try{
                                                if(serverSocket != null){
                                                    serverSocket.close();
                                                    serverSocket = null;
                                                }
                                            }catch (IOException e){
                                                //nothing
                                            }
                                            try {
                                                System.out.println("INFO: Made process");

                                                serverSocket = new ServerSocket(agentPort);
                                                ctx.getSource().method_9226(() -> class_2561.method_43470("Java Server Ready, Port: " + agentPort + "..."), false);
                                                socket = serverSocket.accept();
                                                socket.setTcpNoDelay(true);
                                                socket.setSoTimeout(0);

                                                input = new DataInputStream(socket.getInputStream());
                                                output = new DataOutputStream(socket.getOutputStream());
                                                System.out.println("INFO: Socket Connected");

                                                int agent_info_dim = 21;
                                                int numItems = class_7923.field_41178.method_10204();
                                                int numBlocks = class_7923.field_41175.method_10204();
                                                int numEntities = class_7923.field_41177.method_10204();


                                                output.writeInt(agent_info_dim);
                                                output.writeInt(numItems);
                                                output.writeInt(numBlocks);
                                                output.writeInt(numEntities);
                                                output.flush();

                                                resetPlayer = true;
    //                                            out.println("exit");
    //                                            System.out.println("Python replied: " + in.readLine());

    //                                            socket.close();
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                                System.out.println("ERROR: FAILED ");
                                            }
                                            System.out.println("Success? ");

                                            movementActions.put(0, this::moveForward);
                                            movementActions.put(1, this::moveBackward);
                                            movementActions.put(2, this::moveLeft);
                                            movementActions.put(3, this::moveRight);
                                            movementActions.put(4, this::moveForward);
                                            movementActions.put(5, null);

                                            panCam.put(0, this::lookUp);
                                            panCam.put(1, this::lookDown);
                                            panCam.put(2, this::rotateLeft);
                                            panCam.put(3, this::rotateRight);
                                            panCam.put(4, null);

                                            checkpoints.put(new Tuple3((int)Math.floor(186/REGION), 0, (int)Math.floor(-206/REGION)), 50.0f);
                                            checkpoints.put(new Tuple3((int)Math.floor(192/REGION), 0, (int)Math.floor(-205/REGION)), 55.0f);
                                            checkpoints.put(new Tuple3((int)Math.floor(191/REGION), 0, (int)Math.floor(-200/REGION)), 50.0f);
                                            checkpoints.put(new Tuple3((int)Math.floor(189/REGION), 0, (int)Math.floor(-197/REGION)), 60.0f);
                                            checkpoints.put(new Tuple3((int)Math.floor(188/REGION), 0, (int)Math.floor(-200/REGION)), 70.0f);
                                            checkpoints.put(new Tuple3((int)Math.floor(184/REGION), 0, (int)Math.floor(-209/REGION)), 100.0f); // Major intersection

                                            // Two exit points
                                            checkpoints.put(new Tuple3((int)Math.floor(193/REGION), 0, (int)Math.floor(-212/REGION)), 300.0f);
                                            checkpoints.put(new Tuple3((int)Math.floor(186/REGION), 0, (int)Math.floor(-219/REGION)), 300.0f);

                                            return 1;
                }))));


            dispatcher.register(method_9247("get_port").executes(ctx -> {
                ctx.getSource().method_9226(() -> class_2561.method_43470("PORT: " + agentPort), false);
                return 1;
            }));

            dispatcher.register(method_9247("changeLookWood").executes(ctx -> {
                doLookWood = !doLookWood;
                ctx.getSource().method_9226(() -> class_2561.method_43470("Look Wood Reward set to: " + doLookWood), false);
                return 1;
            }));

            dispatcher.register(method_9247("debug_checkpoint_on").executes(ctx -> {
                DEBUGCHECKPOINT = true;
                ctx.getSource().method_9226(() -> class_2561.method_43470("Checkpoint Debug On"), false);
                return 1;
            }));

            dispatcher.register(method_9247("debug_stuck_on").executes(ctx -> {
                DEBUGSTUCK = true;
                ctx.getSource().method_9226(() -> class_2561.method_43470("Stuck Debug On"), false);
                return 1;
            }));

            dispatcher.register(method_9247("debug_off").executes(ctx -> {
                DEBUGCHECKPOINT = false;
                DEBUGSTUCK = false;
                return 1;
            }));


            dispatcher.register(method_9247("stop_training").executes(ctx -> {
                MinecraftServer server = ctx.getSource().method_9211();

                server.method_3734().method_44252(server.method_3739(), "/player " + agentName + " kill");

                agent = null;
                agentName = null;

                collecting = false;

                if(socket != null && !socket.isClosed()) {
                    try {
                        socket.close();
                        serverSocket.close();
                        ctx.getSource().method_9226(() -> class_2561.method_43470("Java Socket Closed, Port: " + agentPort + "..."), false);
                        socket = null;
                        serverSocket = null;
                    }
                    catch (IOException e) {
                        // ignore?
                    }

                }

                ctx.getSource().method_9226(() -> class_2561.method_43470("Stopped training!"), false);
                return 1;
            }));

            dispatcher.register(method_9247("close_socket").executes(ctx -> {
                if (socket != null && !socket.isClosed()) {
                    try {
                        socket.close();
                        socket = null;
                    } catch (IOException e) {
                        //ignore already closed, shouldn't ever really hit this
                    }

                }
                return 1;
            }));

            dispatcher.register(method_9247("save_state").executes(ctx -> {
                penalty = 10000000;
                return 1;
            }));
        });


        /*
         ************************************************
         **   Main State Information Collection Loop   **
         ************************************************
         */
        ServerTickEvents.END_SERVER_TICK.register(server -> {
                    if (!collecting) return; // only run if training started

                    if(spawnPlayer){
                        server.method_3734().method_44252(server.method_3739(), "/player " + agentName + " spawn");
                        spawnPlayer = false;
                        return;
                    }
                    if (agent == null && agentName != null) {
                        for (class_3222 player : server.method_3760().method_14571()) {
                            if (agentName.equals(player.method_5477().getString().toLowerCase())) {
                                agent = player;
                                world = agent.method_51469();
                                resetPlayer();
                                server.method_3734().method_44252(server.method_3739(), "/gamemode survival " + agentName);
                                System.out.println("found");
                                break;
                            }
                        }
                        if (agent == null) return;
                    }
                    if (agent == null) return;
                    // Agent Position Information
                    if (resetPlayer) {
                        server.method_3734().method_44252(server.method_3739(), "/player " + agentName + " kill");
                        resetPlayer = false;
                        waitForNextRollout = true;
                        return;
                    }


            if(waitForNextRollout) {
                        lastPos = null;
                        try {
                            System.out.println("INFO: Waiting for next rollout");

                            int startRollout = input.readInt();
                            spawnPlayer = true;
                            server.method_3734().method_44252(server.method_3739(), "/time set day");
                            resetPlayer();
                            if(startRollout > 0) {
                                waitForNextRollout = false;
                                sendState = true;
                            }
                        }catch (IOException e) {
                            System.err.println("Error reading rollout command: " + e.getMessage());
                        }
                        agent = null;
                        return;
                    }

                    if(!server.method_3760().method_14571().contains(agent)){
                        penalty = -10.0f;
                        //                                done_tag = 1;
                        server.method_3734().method_44252(server.method_3739(), "/player " + agentName + " spawn");
                        agent = null;
                        return;
                    }

                    if (sendState) {
                        sendStateInfo(server);
                        sendState = false;
                        recieveAction = true;
                        return;
                    }
            List<Float> actions = null;
//            Recieve action
                    if (recieveAction) {
                        try {
                            int respLen = input.readInt();
                            byte[] resp = input.readNBytes(respLen);

                            Action action = Action.parseFrom(resp);

                            actions = action.getActionsList();

                            applyAction(actions);

//                            System.out.println(Arrays.deepToString(actions.toArray()));

                            recieveAction = false;
                            sendReward = true;
                            if (agent == null) return;
                        } catch (Exception e) {

                        }
                    }

                    if (sendReward) {
                        try{
                            float reward = (float) getReward(actions) + penalty;
//                            System.out.println("Reward: " + reward);
                            int done_tag = penalty == -10.0f ? 1 : 0;
                            penalty = 0;

                            class_243 currentPos = new class_243(agent.method_23317(), agent.method_23318(), agent.method_23321());

                            int rx = (int)Math.floor(currentPos.field_1352 / REGION);
                            int rz = (int)Math.floor(currentPos.field_1350 / REGION);

                            Tuple3 mazePos = new Tuple3(rx, 0, rz);
                            if(checkpoints.containsKey(mazePos)){
                                if(checkpoints.get(mazePos) == 300){
                                    done_tag = 1;
                                    server.method_3734().method_44252(server.method_3739(), "/kill " + agentName);
                                    agent = null;
                                }
                            }

                            output.writeFloat(reward);
                            output.writeInt(done_tag);
                            output.flush();

                            sendReward = false;


                            int continueRollout = input.readInt();

                            if(continueRollout == 1){
                                sendState = true;
                            } else{
                                resetPlayer = true;
                            }


                        }
                    catch(IOException e){
                        System.out.println("ERROR: FAILED");
                        server.method_3734().method_44252(server.method_3739(), "/stop_training");
                    }
                }

        });

    }
    private void resetPlayer() {
        visitedRegion.clear();
        visitedWood.clear();
        lastY = null;
        lastPos = null;
        lastMovement = 0;
        prevMoveAction = -1;
        isStuck = false;
        forwardConsistency = 0;
        stuckCounter = 0;
        prev_num_logs = 0;
    }
    private double getReward(List<Float> actions) {
         try {
                class_243 currentPos = new class_243(agent.method_23317(), agent.method_23318(), agent.method_23321());

                if (lastPos == null) {
                    lastPos = currentPos;
                    agentPrevhealth = agent.method_6032();
                    return 0.0;
                }

                double reward = 0.0;

                // ---------------------------
                // 1. Novelty reward (MAIN)
                // ---------------------------
                int rx = (int)Math.floor(currentPos.field_1352 / REGION);
                int rz = (int)Math.floor(currentPos.field_1350 / REGION);

                Tuple3 mazePos = new Tuple3(rx, 0, rz);
                boolean isNew = visitedRegion.add(mazePos);


            if (nearestWood != null) {
                double current_dist_to_wood = Math.sqrt(Math.pow(currentPos.field_1352 - nearestWood.method_10263(), 2) + Math.pow(currentPos.field_1350 - nearestWood.method_10260(), 2));
                double prev_dist_to_wood = Math.sqrt(Math.pow(lastPos.field_1352 - nearestWood.method_10263(), 2) + Math.pow(lastPos.field_1350 - nearestWood.method_10260(), 2));
                double diff = (prev_dist_to_wood - current_dist_to_wood);
                reward += diff;

                class_239 lookingAt = raycastWithEntities(agent, 4.5);

                if (lookingAt instanceof class_3965 bhs) {
                    class_2338 pos = bhs.method_17777();
                    class_2680 state = agent.method_51469().method_8320(pos);

                    boolean isLog = state.method_26164(class_3481.field_15475);
                    if (isLog && doLookWood) {
                        reward += 1;
                    }
                }

                if (current_dist_to_wood <= 2.5) {
                    visitedWood.add(new Tuple3(nearestWood.method_10263(), nearestWood.method_10264(), nearestWood.method_10260()));
                    nearestWood = null;
                }
            }

            var agentInventory = agent.method_31548();
            int num_logs = 0;
            for(int i = 0; i <= agentInventory.method_5439(); i++) {
                class_1799 stack = agentInventory.method_5438(i);
                if (stack != null || stack.method_7960()) continue;

                if(stack.method_31573(class_3489.field_15539)){
                    num_logs += stack.method_7947();
                }
            }

            if(num_logs > prev_num_logs){
                reward += 30; // Big reward, this is current goal
            }
            prev_num_logs = num_logs;

                // ---------------------------
                // 2. Movement reward
                // ---------------------------
                double dx = currentPos.field_1352 - lastPos.field_1352;
                double dz = currentPos.field_1350 - lastPos.field_1350;
                double dist = Math.sqrt(dx*dx + dz*dz);

//                if (dist > 0.05)
//                    reward += dist * 0.2;

                // ---------------------------
                // 3. Collision penalty
                // ---------------------------
                boolean isTryingToMove = actions.getFirst() <= 4;
                boolean collided = agent.field_5976;

                if (collided && isTryingToMove) {
                    reward -= 0.25;
                    if(DEBUGSTUCK){
                        cmdSrc.method_9226(() -> class_2561.method_43470("Agent is Stuck"), false);
                    }
                }

                // ---------------------------
                // 4. Jump penalty
                // ---------------------------
                boolean jumped = (actions.getFirst() == 4 || actions.getFirst() == 5);

                if (jumped)
                    reward -= 0.05;

                if (!agent.method_24828() && !agent.method_5771())
                    reward -= 0.01;

                // ---------------------------
                // 5. Lava / fire / damage
                // ---------------------------
                if (agent.method_5771() || agent.method_5809())
                    reward -= 1.0;

                if (agent.method_6032() < agentPrevhealth)
                    reward -= 1.0;

                // ---------------------------
                // 6. Update state
                // ---------------------------
                lastPos = currentPos;
                agentPrevhealth = agent.method_6032();
                return reward;

            } catch (Exception e) {
                return 0.0;
            }
        }


    private void applyAction(List<Float> actions) {
        if (agent == null) return;
        int movement = actions.get(0).intValue();
//        int jump = actions.get(1).intValue();
        int item_use = actions.get(1).intValue();
        int hotbar_idx = actions.get(2).intValue();
        int pan_id = actions.get(3).intValue();

        Runnable movementAction = null;

        if(movement <= 4){ // only care about actual movement, not jumping or standing still
            prevMoveAction = movement;
            movementAction = movementActions.get(movement);
        }else{
            prevMoveAction = -1;
        }
        if (movementAction != null) {
            movementAction.run();
        }

        int jump = 0;
        if(movement == 4 || movement == 5){
            jump = 1;
        }

        if(jump > 0 && agent.method_24828() || agent.method_5771() || agent.method_5869()) {
            agent.method_6043();
        }


        // 2 is don't use item
        if(item_use == 0)
            tryHit();
        else if(item_use == 1)
            tryPlace();
        else
            stopMiningIfNeeded();

        if(hotbar_idx != currentHand){
            agent.method_31548().method_61496(hotbar_idx);
            currentHand = hotbar_idx;
        }

        Runnable pan_cam_action = panCam.get(pan_id);
        if (pan_cam_action != null) {
            pan_cam_action.run();
        }


    }

    private class_2338 miningPos = null;
    private int miningTicks = 0;
    private class_2350 miningDir = null;

    private void tryHit() {
        class_239 hit = raycastWithEntities(agent, 4.5);
        agent.method_6104(class_1268.field_5808); // Swings
        if(hit instanceof class_3966 ehr){
            class_1297 target = ehr.method_17782();
            agent.method_6104(class_1268.field_5808);
            agent.method_7324(target);
            agent.method_7350();
        }
        else if(hit instanceof class_3965 bhr) {

            class_2338 pos = bhr.method_17777();
//            Direction dir = bhr.getSide();
            // Start/continue mining'
            class_2680 state = world.method_8320(pos);
            if(!pos.equals(miningPos)) {
                stopMiningIfNeeded();
                agent.field_13974.method_14263(pos, class_2846.class_2847.field_12968, miningDir, world.method_31605(), 0);

                miningPos = bhr.method_17777().method_10062();
                miningDir = bhr.method_17780();
                miningTicks = 0;
                return;
            }
            miningTicks++;
            float delta = state.method_26165(agent, world, pos);
            float progress = delta * (miningTicks + 1);

            // If block is fully mined, STOP will break it
            if (progress >= 0.99f) {
                boolean isLog = state.method_26164(class_3481.field_15475);
                if (isLog && doLookWood) {
                    penalty += 10;
                }


                agent.field_13974.method_14263(
                        pos,
                        class_2846.class_2847.field_12973,
                        miningDir,
                        world.method_31605(),
                        0
                );
                miningPos = null;
                miningTicks = 0;
                miningDir = null;
            }

            return;
        }
        stopMiningIfNeeded();
    }

    private class_239 raycastWithEntities(class_3222 player, double reach) {
        class_243 start = player.method_5836(1.0f);
        class_243 look = player.method_5828(1.0f);
        class_243 end = start.method_1019(look.method_1021(reach));

        // First, block raycast (vanilla)
        class_239 blockHit = player.method_5745(reach, 1.0f, false);

        // Now check for entities along the line
        class_238 box = player.method_5829().method_18804(look.method_1021(reach)).method_1014(1.0D);

        class_3966 entityHit = class_1675.method_18075(
                player,
                start,
                end,
                box,
                entity -> !entity.method_7325() && entity.method_5732(),
                reach * reach
        );

        // Return entity hit if it is closer than block hit
        if (entityHit != null) {
            double entityDist = entityHit.method_17784().method_1025(start);
            double blockDist = blockHit.method_17784().method_1025(start);

            if (entityDist < blockDist) {
                return entityHit;
            }
        }

        return blockHit;
    }

    private void stopMiningIfNeeded() {
        if (miningPos != null) {
            agent.field_13974.method_14263(
                    miningPos,
                    class_2846.class_2847.field_12971,
                    miningDir,
                    world.method_31605(),
                    0
            );
            miningPos = null;
            miningDir = null;
            miningTicks = 0;        }
    }

    public void tryPlace() {
        class_239 hit = raycastWithEntities(agent, 4.5);
        if(hit.method_17783() == class_239.class_240.field_1333) {
            agent.field_13974.method_14256(agent, world, agent.method_6047(), class_1268.field_5808);
            return;
        }
        if(hit instanceof class_3965 bhr && bhr.method_17783() == class_239.class_240.field_1332) {
            agent.method_6104(class_1268.field_5808);

            class_1269 result = agent.field_13974.method_14262(
                    agent,
                    world,
                    agent.method_6047(),
                    class_1268.field_5808,
                    bhr
            );
        }


    }


    private void rotateLeft() {
        agent.method_36456(agent.method_36454() - 5f);  // turn 5 degrees left
    }

    private void rotateRight() {
        agent.method_36456(agent.method_36454() + 5f);  // turn 5 degrees right
    }

    private void lookUp() {
        agent.method_36457(Math.max(agent.method_36455() - 3f, -89f)); // can't look past straight up
    }

    private void lookDown() {
        agent.method_36457(Math.min(agent.method_36455() + 3f, 89f)); // can't look past straight down
    }

    private void clip_velocity(){
        class_243 vel = agent.method_18798();
        double horizSpeed = Math.sqrt(vel.field_1352 * vel.field_1352 + vel.field_1350 * vel.field_1350);

        if(horizSpeed > maxSpeed){
            double scaled = maxSpeed / horizSpeed;
            class_243 new_vel = new class_243(vel.field_1352 * scaled, vel.field_1351, vel.field_1350 * scaled);
            agent.method_18799(new_vel);
        }
    }

    private void moveForward(){
        class_243 lookDir = agent.method_5828(1.0F);

        class_243 movement = new class_243(lookDir.field_1352 * speed, 0, lookDir.field_1350 * speed);
        agent.method_60491(movement);

        clip_velocity();
    }

    private void moveBackward(){
        class_243 lookDir = agent.method_5828(1.0F);

        class_243 movement = new class_243(lookDir.field_1352 * -speed, 0, lookDir.field_1350 * -speed);
        agent.method_60491(movement);

        clip_velocity();
    }

    private void moveRight(){
        class_243 lookDir = agent.method_5828(1.0F);

        class_243 movement = new class_243(-lookDir.field_1350 * speed, 0, lookDir.field_1352 * speed);
        agent.method_60491(movement);

        clip_velocity();
    }

    private void moveLeft(){
        class_243 lookDir = agent.method_5828(1.0F);

        class_243 movement = new class_243(lookDir.field_1350 * speed, 0, -lookDir.field_1352 * speed);
        agent.method_60491(movement);

        clip_velocity();
    }


//    private void jump(){
//        if (agent.isOnGround()) {
//            Vec3d vel = agent.getVelocity();
//            agent.setVelocity(vel.x, 0.5, vel.z);
//            wasOnGround = true;
//
//        }
//    }

    private void updateHand(int jump){

    }

    private void sendStateInfo(MinecraftServer server){
        double[] agentInfo = getAgentInfo();
        // Get agent inventory
        // Pass through transformer to encode values as a flattened vector
        double[][] inventoryArray = getInventory();

        // Get nearby entities
        double[][] nearbyEntities = getNearbyEntities();

        // Get nearby Block information
        double[][][] nearbyBlocks = getNearbyBlocks();

        // prolly could hard code this into the function?
        List<Double> agentInfoList = new ArrayList<>(agentInfo.length);
        for (double value : agentInfo) {
            agentInfoList.add(value);
        }

        Matrix.Builder inventoryMatrix = Matrix.newBuilder();
        for(double[] row : inventoryArray) {
            Row.Builder rowBuilder = Row.newBuilder();
            for(double value : row) {
                rowBuilder.addValues(value);
            }
            inventoryMatrix.addRows(rowBuilder);
        }

        Matrix.Builder nearbyEntitiesMatrix = Matrix.newBuilder();
        for(double[] row : nearbyEntities) {
            Row.Builder rowBuilder = Row.newBuilder();
            for(double value : row) {
                rowBuilder.addValues(value);
            }
            nearbyEntitiesMatrix.addRows(rowBuilder);
        }

        Matrix3D.Builder nearbyBlocksMatrix = Matrix3D.newBuilder();
        for(double[][] matrix : nearbyBlocks) {
            Matrix.Builder matrixBuilder = Matrix.newBuilder();
            for(double[] row : matrix) {
                Row.Builder rowBuilder = Row.newBuilder();
                for(double value : row) {
                    rowBuilder.addValues(value);
                }
                matrixBuilder.addRows(rowBuilder);
            }
            nearbyBlocksMatrix.addMatrix(matrixBuilder);
        }

        State stateInfo = State.newBuilder()
                .addAllAgentInfo(agentInfoList)
                .setInventory(inventoryMatrix)
                .setNearbyEntities(nearbyEntitiesMatrix)
                .setNearbyBlocks(nearbyBlocksMatrix)
                .build();

        try {
            byte[] payload = stateInfo.toByteArray();
            output.writeInt(payload.length);
            output.write(payload);
            output.flush();
        } catch (IOException e) {
            e.printStackTrace();
            server.method_3734().method_44252(server.method_3739(), "/stop_training");
            System.out.println("Failed to send data to python, shutting down training...");
        }
    }


    public double[] getAgentInfo(){
        double health = agent.method_6032();
        double hunger = agent.method_7344().method_7586();
        double saturation = agent.method_7344().method_7589();

//        double[] agentPos = getPos();

        class_243 vel = agent.method_18798();
        double vx = vel.field_1352;
        double vy = vel.field_1351;
        double vz = vel.field_1350;

        health /= 20.0;
        hunger /= 20.0;
        saturation /= 20.0;
        vy /= 0.5;
        vx /= speed;
        vz /= speed;

        class_2680 blockBelow = world.method_8320(agent.method_24515().method_10074());
        double blockBelowId = class_2248.field_10651.method_10206(blockBelow);

        double colliding = agent.field_5976 || agent.field_5992 ? 1 : 0;
        double isSneak = agent.method_5715() ? 1 : 0;

        double isOnFire = agent.method_5809() ? 1 : 0;
        double inWater = agent.method_5799() ? 1 : 0;
        double inLava = agent.method_5771() ? 1 : 0;
        double onGround = agent.method_24828() ? 1 : 0;
        double isFalling  = vy < -0.6 ? 1 : 0;
        double wasHurt = agent.field_6235 > 0 ? 1 : 0;

        double mainHandCount = agent.method_6047().method_7947();
        double mainHandSlot = agent.method_31548().method_67532();

        double time = (double) (world.method_8510() % 24000) / 24000.0;

        double lightLevel = world.method_22339(agent.method_24515()) / 15.0;

        class_239 raycast = raycastWithEntities(agent, 4.5);

        double looking_at = 0;
        double looking_at_id = 0;

        double[] row;
        switch(raycast.method_17783()) {
            case field_1332:
                looking_at = 1;

                class_3965 blockHit = (class_3965) raycast;
                class_2338 pos = blockHit.method_17777();
                class_2680 state = agent.method_51469().method_8320(pos);

                row = new double[]{
                        class_7923.field_41175.method_10206(state.method_26204()),
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                };
                break;
            case field_1331:
                looking_at = 2;

                class_3966 entityHit = (class_3966) raycast;
                class_1297 e = entityHit.method_17782();

                row = new double[]{
                        class_7923.field_41177.method_10206(e.method_5864()),
                        (e instanceof class_1569) ? 1 : 0,
                        (e instanceof class_5354) ? 1 : 0,
                        (e instanceof class_1296) ? 1 : 0,
                        ((!(e instanceof class_1569)) && (!(e instanceof class_5354)) && (!(e instanceof class_1296))) ? 1 : 0,
                        e.method_23317() - agent.method_23317(),
                        e.method_23318() - agent.method_23318(),
                        e.method_23321() - agent.method_23321()
                };
                break;
            default:
                row =  new double[]{
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                };
                break;
        }

        double normYaw = agent.method_36454() / 180.0;
        double normPitch = agent.method_36455() / 90.0;

        double[] agentInfo = new double[]{
                health,
                hunger,
                saturation,
                normYaw,
                normPitch,
                vx,
                vy,
                vz,
                blockBelowId,
                colliding,
                isSneak,
                isOnFire,
                inWater,
                inLava,
                onGround,
                isFalling,
                wasHurt,
                mainHandCount,
                mainHandSlot,
                time,
                lightLevel,
                looking_at,
                row[0],
                row[1],
                row[2],
                row[3],
                row[4],
                row[5],
                row[6],
                row[7],
        };

        return agentInfo;
    }
    public double[] getPos() {
        return new double[]{ agent.method_23317(), agent.method_23318(), agent.method_23321(), agent.method_36454(), agent.method_36455() };
    }

    /**
     * Used to collect the possible utility values of an item
     * @param item The {@link class_1792} to find the possible utilities of
     * @param itemType The {@link int[]} representing the type of item, if provided [isArmor, isFodd, isTool, isWeapon]
     * @return array of 2 values representing 2 utility options.
     *         isArmor: [protection, toughness]
     *         isFood: [nutrition, saturation]
     *         isTool: [dmg per block, default mining speed]
     *         isWeapon: [dmg, attack speed]
     */
    public double[] getUtility(class_1792 item, int[] itemType) {
        double[] utility = {0, 0};
        // isArmor
        if(itemType[0] == 1) {
            // [protection, toughness]
            class_9285 modifiers = item.method_57347().method_58694(class_9334.field_49636);

            if (modifiers == null) return utility;

            for (var modifier : modifiers.comp_2393()) {
                if (modifier.comp_2395().equals(class_5134.field_23724)) {
                    utility[0] += modifier.comp_2396().comp_2449();
                }
                if (modifier.comp_2395().equals(class_5134.field_23725)) {
                    utility[1] += modifier.comp_2396().comp_2449();
                }
            }
        }
        // isFood
        else if(itemType[1] == 1) {
            // [nutrition (hunger fill), saturation (how long)]
            class_4174 food = item.method_57347().method_58694(class_9334.field_50075);

            if (food == null) return utility;

            utility[0] = food.comp_2491();
            utility[1] = food.comp_2492();
        }
        // isTool
        else if(itemType[2] == 1){
            // [damage per block, default mining speed]
            class_9424 tool = item.method_57347().method_58694(class_9334.field_50077);

            if(tool == null) return utility;

            utility[0] = tool.comp_2500();
            utility[1] = tool.comp_2499();
        }
        //isWeapon
        else if(itemType[3] == 1){
            // Handle Ranged weapons
            // [based dmg, draw time]
            if (item instanceof class_1753) {
                utility[0] = 6.0;
                utility[1] = 0.80;
                return utility;
            }
            if  (item instanceof class_1764) {
                utility[0] = 6.0;
                utility[1] = 0.50;
                return utility;
            }

            // [damage, attack speed]
            class_9285 modifiers = item.method_57347().method_58694(class_9334.field_49636);

            if (modifiers == null) return utility;

            for (var modifier : modifiers.comp_2393()) {
                if (modifier.comp_2395().equals(class_5134.field_23721)) {
                    utility[0] += modifier.comp_2396().comp_2449();
                }
                if (modifier.comp_2395().equals(class_5134.field_23723)) {
                    utility[1] += modifier.comp_2396().comp_2449();
                }
            }

        }
        return utility;
    }

    /**
     * Gets the agent inventory.
     * 0–8   : Hotbar
     * 9–35  : Main inventory
     * 36–39  : Armor (boots → leggings → chestplate → helmet)
     * 40     : Off-hand
     * 41–44  : Crafting grid output + 2x2 crafting input (ignored)
     *
     * @return double[][] where each row =
     *         [item_id, isArmor, isFood, isTool, isWeapon, utility1, utility2, count, durability]
     *         Check getUtility function for posible utility values
     */
    public double[][] getInventory(){
        class_1661 agentInventory = agent.method_31548();
        double[][] inventoryArray =  new double[41][9];

        for(int i = 0; i <= 40; i++) {
            class_1799 stack = agentInventory.method_5438(i);
            class_1792 item = stack.method_7909();

            int item_id = class_7923.field_41178.method_10206(item);
            double count = stack.method_7947() / 64.0;

            int max = stack.method_7936();
            double durability;

            int isDamageable = (max > 0) ? 1 : 0;
            if (max > 0) {
                durability = (double)(max - stack.method_7919()) / (double) max; // in [0,1]
            } else {
                durability = 0.0; // or 1.0, but be consistent; add isDamageable flag if you can
            }

            // ------ Get Boolean Values For one-hot encoding of item type ------ //
            class_10192 equip = item.method_57347().method_58694(class_9334.field_54196);
            int isArmor = 0;
            if(equip != null) {
                class_1304 slot = equip.comp_3174();
                isArmor = (slot.method_5925() == class_1304.class_1305.field_6178) ? 1 : 0;
            }

            boolean toolBool = item.method_57347().method_57832(class_9334.field_50077);
            boolean foodBool = item.method_57347().method_57832(class_9334.field_50075);
            boolean weaponBool = item == class_1802.field_8091 || item == class_1802.field_8528 || item == class_1802.field_8371 || item == class_1802.field_8845 || item == class_1802.field_8802 || item == class_1802.field_22022;
            boolean rangedWeaponBool = item instanceof class_1753 || item instanceof class_1764 || item instanceof class_1835;

            int isTool = toolBool ? 1 : 0;
            int isFood = foodBool ? 1 : 0;
            int isWeapon = 0;

            if(weaponBool || rangedWeaponBool) {
                // Sword is both tool and weapon, but we want it to only be classified as weapon
                isWeapon = 1;
                isTool = 0;
            }

            int[] itemType = {isArmor, isFood, isTool, isWeapon};

            // Get utility value based on what the item is. We will get 2 per option
            double[] utility_value = getUtility(item, itemType);

            inventoryArray[i][0] = item_id;
            inventoryArray[i][1] = isArmor;
            inventoryArray[i][2] = isFood;
            inventoryArray[i][3] = isTool;
            inventoryArray[i][4] = isWeapon;
            inventoryArray[i][5] = utility_value[0];
            inventoryArray[i][6] = utility_value[1];
            inventoryArray[i][7] = count;
            inventoryArray[i][8] = durability;
        }

        return inventoryArray;
    }

    /**
     * Gets Entities within a given radius of the agent
     * @return double[][] where each row =
     *         [entity id, isMonster, isAngerable, isPassive, isUnknown, x, y, z]
     */
    public double[][] getNearbyEntities(){
        double agentSearchRadius = 10.0;
        double[][] foundEntities = new double[10][8];

        class_238 box = agent.method_5829().method_1014(agentSearchRadius);
        List<class_1297> nearbyEntities = agent.method_51469().method_8335(agent, box);

        int idx = 0;
        for (class_1297 entity : nearbyEntities) {
            if (idx >= 10) break;
            if (entity instanceof class_1657 || !(entity instanceof class_1309)) continue;

            int isMonster = entity instanceof class_1569 ? 1 : 0;
            int isAngerable = entity instanceof class_5354 ? 1 : 0;
            int isPassive = entity instanceof class_1296 ? 1 : 0;
            int isUnknown = (isMonster != 1 && isAngerable != 1 && isPassive != 1) ? 1 : 0;

            foundEntities[idx][0] = class_7923.field_41177.method_10206(entity.method_5864());
            foundEntities[idx][1] = isMonster;
            foundEntities[idx][2] = isAngerable;
            foundEntities[idx][3] = isPassive;
            foundEntities[idx][4] = isUnknown;
            foundEntities[idx][5] = entity.method_23317() - agent.method_23317();
            foundEntities[idx][6] = entity.method_23318() - agent.method_23318();
            foundEntities[idx][7] = entity.method_23321() - agent.method_23321();

            idx++;
        }

        // Runs and sets default value for no entities if less than 10 entities found
        for(int i = idx; i < 10; i++) {
            Arrays.fill(foundEntities[i], 0);
        }

        return foundEntities;
    }

    /**
     * Gets nearby blocks of the agent given a radius
     * @return double[][] where each row =
     *         [Block id, x, y, z]
     */
    public double[][][] getNearbyBlocks() {
        int coreRadius = 8;
        int verticalRadius = 4; // Vertical space not as significant

        double[][][] foundBlocks = new double[coreRadius * 2 + 1][verticalRadius * 2 + 1][coreRadius * 2 + 1];

        int agentBlockX = agent.method_31477();
        int agentBlockY = agent.method_31478();
        int agentBlockZ = agent.method_31479();

        for(int x = agentBlockX - coreRadius; x <= agentBlockX + coreRadius; x++) {
            for (int y = agentBlockY - verticalRadius; y <= agentBlockY + verticalRadius; y++) {
                for(int z = agentBlockZ - coreRadius; z <= agentBlockZ + coreRadius; z++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = agent.method_51469().method_8320(pos);

                    boolean isLog = state.method_26164(class_3481.field_15475);
                    if(isLog) {
                        double dist_to_block = Math.sqrt(Math.pow((agentBlockX - pos.method_10263()), 2) + Math.pow((agentBlockY - pos.method_10264()), 2) + Math.pow((agentBlockZ - pos.method_10260()), 2));
                        if(nearestWood == null){
                            nearestWood = pos; // exclude y to not reward jumping
                        }
                        else {
                            double current_log_dist = Math.sqrt(Math.pow(agentBlockX - nearestWood.method_10263(), 2) + Math.pow(agentBlockY - nearestWood.method_10264(), 2) + Math.pow(agentBlockZ - nearestWood.method_10260(), 2));
                            if(dist_to_block < current_log_dist) nearestWood = pos;
                        }
                    }

                    int relX = x - agentBlockX + coreRadius;       // shift into array bounds
                    int relY = y - agentBlockY + verticalRadius;
                    int relZ = z - agentBlockZ + coreRadius;

                    foundBlocks[relX][relY][relZ] = class_7923.field_41175.method_10206(state.method_26204());
                }
            }
        }

        return foundBlocks;
    }
}