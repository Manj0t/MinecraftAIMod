package me.sand.minecraftaimod.client.mixin;

import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public abstract class InventorySlotNumberMixin<T extends class_1703>
        extends class_437 {

    protected InventorySlotNumberMixin(class_2561 title) {
        super(title);
    }

    @Shadow
    protected T handler;

    @Inject(
            method = "drawForeground",
            at = @At("TAIL")
    )
    private void drawSlotNumbers(class_332 context, int mouseX, int mouseY, CallbackInfo ci) {
        System.out.println("Drawing slot numbers! Slots: " + handler.field_7761.size());

        // Toggleable if you want later

        for (class_1735 slot : handler.field_7761) {
            int x = slot.field_7873;
            int y = slot.field_7872;

            // Slot index
            String text = String.valueOf(slot.field_7874);

            // Small offset so it doesn’t overlap the item
            context.method_51433(
                    class_310.method_1551().field_1772,
                    text,
                    x + 1,
                    y + 1,
                    0xFFFFFF,
                    true
            );
        }
    }
}

