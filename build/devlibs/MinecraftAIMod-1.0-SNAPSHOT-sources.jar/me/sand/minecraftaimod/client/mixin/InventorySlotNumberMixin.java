package me.sand.minecraftaimod.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public abstract class InventorySlotNumberMixin<T extends ScreenHandler>
        extends Screen {

    protected InventorySlotNumberMixin(Text title) {
        super(title);
    }

    @Shadow
    protected T handler;

    @Inject(
            method = "drawForeground",
            at = @At("TAIL")
    )
    private void drawSlotNumbers(DrawContext context, int mouseX, int mouseY, CallbackInfo ci) {
        System.out.println("Drawing slot numbers! Slots: " + handler.slots.size());

        // Toggleable if you want later

        for (Slot slot : handler.slots) {
            int x = slot.x;
            int y = slot.y;

            // Slot index
            String text = String.valueOf(slot.id);

            // Small offset so it doesn’t overlap the item
            context.drawText(
                    MinecraftClient.getInstance().textRenderer,
                    text,
                    x + 1,
                    y + 1,
                    0xFFFFFF,
                    true
            );
        }
    }
}

